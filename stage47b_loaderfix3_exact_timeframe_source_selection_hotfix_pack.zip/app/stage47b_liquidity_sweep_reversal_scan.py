#!/usr/bin/env python3
"""
Stage47B XAUUSD liquidity-sweep reversal scan.

Purpose:
- Predefined, rule-based scan for failed breakout / re-entry reversal.
- No ML, no paper-order, no EA, no live execution.
- Conservative SQLite/CSV loader with schema introspection.
- Emits summary JSON, candidate register CSV, trade CSV, and Markdown report.

Expected candle fields, with aliases accepted:
- timestamp: ts, timestamp, time, datetime, date, open_time, candle_time
- open: open, o
- high: high, h
- low: low, l
- close: close, c
Optional:
- spread: spread, spread_points, bid_ask_spread, ask_bid_spread
- bid/ask: bid, ask, bid_close, ask_close
- symbol: symbol, instrument, pair
- timeframe: timeframe, tf, granularity, interval

Default strategy assumptions are deliberately conservative. This script is a
research scanner only. It does not submit, simulate, or prepare orders.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import random
import re
import sqlite3
import statistics
import sys
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


STAGE = "Stage47B_LIQUIDITY_SWEEP_REVERSAL_SCAN"
STATUS_NO_DATA = "NO_DATA_STOP_NO_PROMOTION"
STATUS_COMPLETE = "SCAN_COMPLETE_NO_PROMOTION"

TS_ALIASES = ["ts", "timestamp", "time", "datetime", "date", "open_time", "candle_time", "utc_time", "time_utc", "ts_utc", "datetime_utc", "utc_ts", "candle_ts", "date_time", "open_ts", "bar_time"]
OPEN_ALIASES = ["open", "o", "open_price", "mid_open", "bid_open", "ask_open"]
HIGH_ALIASES = ["high", "h", "high_price", "mid_high", "bid_high", "ask_high"]
LOW_ALIASES = ["low", "l", "low_price", "mid_low", "bid_low", "ask_low"]
CLOSE_ALIASES = ["close", "c", "close_price", "mid_close", "bid_close", "ask_close", "last"]
SPREAD_ALIASES = ["spread", "spread_points", "spread_point", "bid_ask_spread", "ask_bid_spread", "spread_price", "spread_pips"]
BID_ALIASES = ["bid", "bid_close", "close_bid"]
ASK_ALIASES = ["ask", "ask_close", "close_ask"]
SYMBOL_ALIASES = ["symbol", "instrument", "pair"]
TIMEFRAME_ALIASES = ["timeframe", "tf", "granularity", "interval", "time_frame", "timeframe_norm", "tf_norm", "source_timeframe"]


@dataclass
class Candle:
    ts: datetime
    open: float
    high: float
    low: float
    close: float
    spread: Optional[float] = None
    symbol: Optional[str] = None
    timeframe: Optional[str] = None
    atr14: Optional[float] = None


@dataclass(frozen=True)
class Config:
    candidate_id: str
    reference_range: str
    active_window: str
    sweep_atr_mult: float
    confirmation: str
    target_mode: str
    max_hold_minutes: int


@dataclass
class Trade:
    candidate_id: str
    side: str
    reference_range: str
    active_window: str
    entry_ts: str
    exit_ts: str
    entry: float
    exit: float
    ref_low: float
    ref_high: float
    ref_mid: float
    sweep_extreme: float
    stop: float
    target: float
    gross_points: float
    net_points: float
    net_bps: float
    benchmark_net_bps: float
    hold_minutes: float
    exit_reason: str
    cost_points: float
    atr14: float


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize_name(name: str) -> str:
    return name.strip().lower().replace(" ", "_").replace("-", "_")


def find_col(columns: Sequence[str], aliases: Sequence[str]) -> Optional[str]:
    norm = {normalize_name(c): c for c in columns}
    for alias in aliases:
        if alias in norm:
            return norm[alias]
    return None


def parse_ts(value: Any) -> datetime:
    if isinstance(value, datetime):
        dt = value
    elif isinstance(value, (int, float)):
        # Heuristic: ms epoch is too large for seconds.
        ts_float = float(value)
        if ts_float > 10_000_000_000:
            ts_float /= 1000.0
        dt = datetime.fromtimestamp(ts_float, tz=timezone.utc)
    else:
        s = str(value).strip()
        if not s:
            raise ValueError("empty timestamp")
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        # Common MT5 / CSV style without timezone.
        if "T" not in s and " " in s:
            s = s.replace(" ", "T", 1)
        try:
            dt = datetime.fromisoformat(s)
        except ValueError:
            # Last-resort common formats.
            for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%Y.%m.%dT%H:%M:%S", "%Y.%m.%dT%H:%M"):
                try:
                    dt = datetime.strptime(s, fmt)
                    break
                except ValueError:
                    continue
            else:
                raise
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def safe_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        f = float(value)
    else:
        s = str(value).strip()
        if not s or s.lower() in {"nan", "none", "null"}:
            return None
        f = float(s)
    if not math.isfinite(f):
        return None
    return f


def infer_spread(row: Dict[str, Any], spread_col: Optional[str], bid_col: Optional[str], ask_col: Optional[str]) -> Optional[float]:
    if spread_col:
        v = safe_float(row.get(spread_col))
        if v is not None and v >= 0:
            return v
    if bid_col and ask_col:
        bid = safe_float(row.get(bid_col))
        ask = safe_float(row.get(ask_col))
        if bid is not None and ask is not None and ask >= bid:
            return ask - bid
    return None


def row_to_candle(
    row: Dict[str, Any],
    mapping: Dict[str, Optional[str]],
    default_symbol: Optional[str] = None,
    default_timeframe: Optional[str] = None,
) -> Optional[Candle]:
    try:
        ts_col = mapping["ts"]
        o_col = mapping["open"]
        h_col = mapping["high"]
        l_col = mapping["low"]
        c_col = mapping["close"]
        if not all([ts_col, o_col, h_col, l_col, c_col]):
            return None
        ts = parse_ts(row[ts_col])
        o = safe_float(row[o_col])
        h = safe_float(row[h_col])
        l = safe_float(row[l_col])
        c = safe_float(row[c_col])
        if o is None or h is None or l is None or c is None:
            return None
        if h < max(o, c) or l > min(o, c) or h < l:
            # Bad OHLC row; skip rather than repairing.
            return None
        spread = infer_spread(row, mapping.get("spread"), mapping.get("bid"), mapping.get("ask"))
        symbol = str(row.get(mapping["symbol"])).strip() if mapping.get("symbol") and row.get(mapping["symbol"]) is not None else default_symbol
        timeframe = str(row.get(mapping["timeframe"])).strip() if mapping.get("timeframe") and row.get(mapping["timeframe"]) is not None else default_timeframe
        return Candle(ts=ts, open=o, high=h, low=l, close=c, spread=spread, symbol=symbol, timeframe=timeframe)
    except Exception:
        return None


def detect_mapping(columns: Sequence[str]) -> Dict[str, Optional[str]]:
    return {
        "ts": find_col(columns, TS_ALIASES),
        "open": find_col(columns, OPEN_ALIASES),
        "high": find_col(columns, HIGH_ALIASES),
        "low": find_col(columns, LOW_ALIASES),
        "close": find_col(columns, CLOSE_ALIASES),
        "spread": find_col(columns, SPREAD_ALIASES),
        "bid": find_col(columns, BID_ALIASES),
        "ask": find_col(columns, ASK_ALIASES),
        "symbol": find_col(columns, SYMBOL_ALIASES),
        "timeframe": find_col(columns, TIMEFRAME_ALIASES),
    }


def load_csv(path: Path, symbol: Optional[str], timeframe: Optional[str], limit: int = 0) -> Tuple[List[Candle], Dict[str, Any]]:
    meta: Dict[str, Any] = {"source_type": "csv", "source_path": str(path), "mapping": {}, "raw_rows": 0, "accepted_rows": 0}
    if not path.exists():
        meta["error"] = "CSV_NOT_FOUND"
        return [], meta
    candles: List[Candle] = []
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            meta["error"] = "CSV_NO_HEADER"
            return [], meta
        mapping = detect_mapping(reader.fieldnames)
        meta["mapping"] = mapping
        if not all([mapping["ts"], mapping["open"], mapping["high"], mapping["low"], mapping["close"]]):
            meta["error"] = "CSV_REQUIRED_COLUMNS_NOT_FOUND"
            return [], meta
        for row in reader:
            meta["raw_rows"] += 1
            c = row_to_candle(row, mapping, default_symbol=symbol, default_timeframe=timeframe)
            if c is None:
                continue
            if symbol and c.symbol and c.symbol.upper() != symbol.upper():
                continue
            if timeframe and c.timeframe and normalize_tf(c.timeframe) != normalize_tf(timeframe):
                continue
            candles.append(c)
            if limit and len(candles) >= limit:
                break
    candles.sort(key=lambda x: x.ts)
    meta["accepted_rows"] = len(candles)
    return candles, meta


def sqlite_tables(conn: sqlite3.Connection) -> List[str]:
    cur = conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    return [r[0] for r in cur.fetchall()]


def table_columns(conn: sqlite3.Connection, table: str) -> List[str]:
    cur = conn.execute(f"PRAGMA table_info({quote_ident(table)})")
    return [r[1] for r in cur.fetchall()]


def quote_ident(identifier: str) -> str:
    return '"' + identifier.replace('"', '""') + '"'


def choose_sqlite_table(conn: sqlite3.Connection, requested: Optional[str]) -> Tuple[Optional[str], Dict[str, Any]]:
    meta: Dict[str, Any] = {"available_tables": [], "table_candidates": []}
    tables = sqlite_tables(conn)
    meta["available_tables"] = tables
    if requested:
        if requested in tables:
            return requested, meta
        meta["error"] = "REQUESTED_TABLE_NOT_FOUND"
        return None, meta

    best: Optional[Tuple[int, str, Dict[str, Optional[str]]]] = None
    preferred_name_tokens = ("candle", "candles", "ohlc", "ohlcv", "bar", "bars", "price", "prices", "xau", "normalized")
    for table in tables:
        cols = table_columns(conn, table)
        mapping = detect_mapping(cols)
        required_score = sum(1 for k in ["ts", "open", "high", "low", "close"] if mapping.get(k))
        optional_score = sum(1 for k in ["spread", "bid", "ask", "symbol", "timeframe"] if mapping.get(k))
        name_score = 3 if any(tok in normalize_name(table) for tok in preferred_name_tokens) else 0
        row_count_score = 0
        try:
            row_count = int(conn.execute(f"SELECT COUNT(*) FROM {quote_ident(table)}").fetchone()[0])
            row_count_score = 1 if row_count >= 200 else 0
        except Exception:
            row_count = None
        total_score = required_score * 10 + optional_score + name_score + row_count_score
        meta["table_candidates"].append({
            "table": table,
            "columns": cols,
            "mapping": mapping,
            "required_score": required_score,
            "optional_score": optional_score,
            "row_count": row_count,
            "score": total_score,
        })
        if required_score >= 5 and (best is None or total_score > best[0]):
            best = (total_score, table, mapping)
    if best is None:
        meta["error"] = "NO_CANDLE_TABLE_DETECTED"
        return None, meta
    return best[1], meta


def sql_text_norm_expr(column: str) -> str:
    q = quote_ident(column)
    return f"UPPER(REPLACE(REPLACE(REPLACE(CAST({q} AS TEXT), ' ', ''), '-', ''), '_', ''))"


def sql_in_list(values: Sequence[str]) -> str:
    return ", ".join("'" + v.replace("'", "''") + "'" for v in values)


def sqlite_count_query(conn: sqlite3.Connection, table: str, where_clause: str = "") -> Optional[int]:
    try:
        q = f"SELECT COUNT(*) FROM {quote_ident(table)}"
        if where_clause:
            q += f" WHERE {where_clause}"
        return int(conn.execute(q).fetchone()[0])
    except Exception:
        return None


def load_sqlite(
    path: Path,
    table: Optional[str],
    symbol: Optional[str],
    timeframe: Optional[str],
    limit: int = 0,
    db_row_cap: int = 300000,
    allow_large_db: bool = False,
) -> Tuple[List[Candle], Dict[str, Any]]:
    meta: Dict[str, Any] = {
        "source_type": "sqlite",
        "source_path": str(path),
        "raw_rows": 0,
        "accepted_rows": 0,
        "db_row_cap": db_row_cap,
        "allow_large_db": allow_large_db,
    }
    if not path.exists():
        meta["error"] = "SQLITE_NOT_FOUND"
        return [], meta
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    try:
        selected_table, choice_meta = choose_sqlite_table(conn, table)
        meta.update(choice_meta)
        if not selected_table:
            return [], meta
        cols = table_columns(conn, selected_table)
        mapping = detect_mapping(cols)
        meta["selected_table"] = selected_table
        meta["mapping"] = mapping

        where_parts: List[str] = []
        if timeframe and mapping.get("timeframe"):
            where_parts.append(f"{sql_text_norm_expr(mapping['timeframe'])} IN ({sql_in_list(timeframe_sql_aliases(timeframe))})")
        if symbol and mapping.get("symbol"):
            symbol_aliases = sorted({symbol.upper(), symbol.upper().replace("/", ""), symbol.upper().replace("_", ""), "XAUUSD", "XAU/USD", "XAU_USD"})
            where_parts.append(f"{sql_text_norm_expr(mapping['symbol'])} IN ({sql_in_list(symbol_aliases)})")
        where_clause = " AND ".join(where_parts)
        meta["sql_where_clause"] = where_clause

        selected_row_count = sqlite_count_query(conn, selected_table, where_clause)
        meta["selected_row_count_after_sql_filter"] = selected_row_count
        if db_row_cap and selected_row_count is not None and selected_row_count > db_row_cap and not allow_large_db:
            meta["error"] = "DB_ROW_CAP_EXCEEDED"
            meta["message"] = "SQLite source is too large for safe default scan. Use normalized CSV or pass --allow-large-db with an explicit --limit if you intentionally want this."
            return [], meta

        quoted_cols = ", ".join(quote_ident(c) for c in cols)
        q = f"SELECT {quoted_cols} FROM {quote_ident(selected_table)}"
        if where_clause:
            q += f" WHERE {where_clause}"
        if mapping.get("ts"):
            q += f" ORDER BY {quote_ident(mapping['ts'])}"
        effective_limit = limit
        if effective_limit:
            q += f" LIMIT {int(effective_limit)}"
        meta["sql_query_mode"] = "filtered_ordered_limited" if effective_limit else "filtered_ordered"

        candles: List[Candle] = []
        for r in conn.execute(q):
            meta["raw_rows"] += 1
            row = {k: r[k] for k in r.keys()}
            c = row_to_candle(row, mapping, default_symbol=symbol, default_timeframe=timeframe)
            if c is None:
                continue
            if symbol and c.symbol and c.symbol.upper() != symbol.upper():
                # This branch only matters if SQL symbol filtering was impossible.
                norm_symbol = c.symbol.upper().replace("/", "").replace("_", "")
                if norm_symbol != symbol.upper().replace("/", "").replace("_", ""):
                    continue
            if timeframe and c.timeframe and normalize_tf(c.timeframe) != normalize_tf(timeframe):
                continue
            candles.append(c)
        candles.sort(key=lambda x: x.ts)
        meta["accepted_rows"] = len(candles)
        return candles, meta
    finally:
        conn.close()

def normalize_tf(tf: Optional[str]) -> Optional[str]:
    """Normalize common timeframe spellings such as 5min, 5M, M5, 15min, 1h."""
    if tf is None:
        return None
    s = str(tf).strip().upper()
    if not s:
        return None
    s = s.replace("_", "").replace("-", "").replace(" ", "")
    s = s.replace("MINUTES", "MIN").replace("MINUTE", "MIN").replace("MINS", "MIN")
    if s in {"1", "01", "M1", "1M", "1MIN"}:
        return "M1"
    if s in {"5", "05", "M5", "5M", "5MIN"}:
        return "M5"
    if s in {"15", "M15", "15M", "15MIN"}:
        return "M15"
    if s in {"30", "M30", "30M", "30MIN"}:
        return "M30"
    if s in {"60", "M60", "60M", "60MIN", "H1", "1H", "1HR", "1HOUR"}:
        return "H1"
    m = re.fullmatch(r"(\d+)(MIN|M)", s)
    if m:
        return f"M{int(m.group(1))}"
    m = re.fullmatch(r"M(\d+)", s)
    if m:
        return f"M{int(m.group(1))}"
    m = re.fullmatch(r"(\d+)H", s)
    if m:
        return f"H{int(m.group(1))}"
    m = re.fullmatch(r"H(\d+)", s)
    if m:
        return f"H{int(m.group(1))}"
    return s


def estimate_timeframe(candles: Sequence[Candle]) -> Optional[str]:
    if len(candles) < 3:
        return None
    deltas = []
    for a, b in zip(candles, candles[1:]):
        m = (b.ts - a.ts).total_seconds() / 60.0
        if 0 < m <= 240:
            deltas.append(m)
    if not deltas:
        return None
    med = statistics.median(deltas)
    if 4 <= med <= 6:
        return "M5"
    if 13 <= med <= 17:
        return "M15"
    return f"M{int(round(med))}"


def add_atr14(candles: List[Candle]) -> None:
    prev_close: Optional[float] = None
    true_ranges: List[float] = []
    for i, c in enumerate(candles):
        if prev_close is None:
            tr = c.high - c.low
        else:
            tr = max(c.high - c.low, abs(c.high - prev_close), abs(c.low - prev_close))
        true_ranges.append(tr)
        if i >= 13:
            c.atr14 = statistics.mean(true_ranges[i - 13 : i + 1])
        else:
            c.atr14 = statistics.mean(true_ranges[: i + 1])
        prev_close = c.close


def date_key(dt: datetime) -> str:
    return dt.date().isoformat()


def quarter_key(dt: datetime) -> str:
    q = ((dt.month - 1) // 3) + 1
    return f"{dt.year}Q{q}"


def in_minutes(dt: datetime) -> int:
    return dt.hour * 60 + dt.minute


def window_bounds(name: str) -> Tuple[int, int]:
    if name == "London":
        return 7 * 60, 10 * 60 + 59
    if name == "NY":
        return 13 * 60, 16 * 60 + 59
    raise ValueError(f"unknown active window: {name}")


def build_day_index(candles: Sequence[Candle]) -> Dict[str, List[Candle]]:
    days: Dict[str, List[Candle]] = {}
    for c in candles:
        days.setdefault(date_key(c.ts), []).append(c)
    return days


def range_from_candles(rows: Sequence[Candle]) -> Optional[Tuple[float, float, float]]:
    if not rows:
        return None
    hi = max(c.high for c in rows)
    lo = min(c.low for c in rows)
    if hi <= lo:
        return None
    return lo, hi, (lo + hi) / 2.0


def asia_range_for_day(day_rows: Sequence[Candle]) -> Optional[Tuple[float, float, float]]:
    rows = [c for c in day_rows if 0 <= in_minutes(c.ts) <= 6 * 60 + 59]
    return range_from_candles(rows)


def prior_day_range(days: Dict[str, List[Candle]], current_day: str) -> Optional[Tuple[float, float, float]]:
    d = datetime.fromisoformat(current_day).date() - timedelta(days=1)
    return range_from_candles(days.get(d.isoformat(), []))


def p75(values: Sequence[float]) -> Optional[float]:
    clean = sorted(v for v in values if v is not None and math.isfinite(v) and v >= 0)
    if not clean:
        return None
    idx = int(math.ceil(0.75 * len(clean))) - 1
    return clean[max(0, min(idx, len(clean) - 1))]


def generate_configs(max_hold_minutes: int) -> List[Config]:
    configs: List[Config] = []
    for reference in ["Asia", "PriorDay"]:
        for window in ["London", "NY"]:
            for mult in [0.10, 0.20, 0.35]:
                for confirmation in ["close_back_inside", "close_back_inside_plus_0.10_ATR"]:
                    for target in ["midpoint", "opposite_side", "1R", "1.5R"]:
                        cid = f"ST47B_{reference}_{window}_SW{mult:.2f}_{confirmation}_{target}".replace(".", "p")
                        configs.append(Config(cid, reference, window, mult, confirmation, target, max_hold_minutes))
    return configs


def signal_threshold(atr: float, mult: float) -> float:
    return max(0.10, mult * atr)


def stop_buffer(atr: float, observed_spread_p75: Optional[float], base_cost_points: float) -> float:
    spread_part = observed_spread_p75 if observed_spread_p75 is not None else base_cost_points
    return max(spread_part, 0.05 * atr)


def active_rows(day_rows: Sequence[Candle], window: str) -> List[Candle]:
    start, end = window_bounds(window)
    return [c for c in day_rows if start <= in_minutes(c.ts) <= end]


def target_price(side: str, mode: str, entry: float, stop: float, ref_low: float, ref_high: float, ref_mid: float) -> Optional[float]:
    risk = abs(entry - stop)
    if risk <= 0:
        return None
    if mode == "midpoint":
        t = ref_mid
    elif mode == "opposite_side":
        t = ref_high if side == "long" else ref_low
    elif mode == "1R":
        t = entry + risk if side == "long" else entry - risk
    elif mode == "1.5R":
        t = entry + 1.5 * risk if side == "long" else entry - 1.5 * risk
    else:
        return None
    if side == "long" and t <= entry:
        return None
    if side == "short" and t >= entry:
        return None
    return t


def resolve_trade(
    future_rows: Sequence[Candle],
    side: str,
    entry: float,
    stop: float,
    target: float,
    max_hold_minutes: int,
) -> Tuple[float, datetime, str, float, float]:
    entry_ts = future_rows[0].ts
    deadline = entry_ts + timedelta(minutes=max_hold_minutes)
    last = future_rows[0]
    for c in future_rows[1:]:
        if c.ts > deadline:
            break
        last = c
        if side == "long":
            stop_hit = c.low <= stop
            target_hit = c.high >= target
        else:
            stop_hit = c.high >= stop
            target_hit = c.low <= target
        if stop_hit and target_hit:
            # Conservative intrabar assumption: adverse hit first.
            return stop, c.ts, "both_hit_stop_first", 0.0, (c.ts - entry_ts).total_seconds() / 60.0
        if stop_hit:
            return stop, c.ts, "stop", 0.0, (c.ts - entry_ts).total_seconds() / 60.0
        if target_hit:
            return target, c.ts, "target", 0.0, (c.ts - entry_ts).total_seconds() / 60.0
    return last.close, last.ts, "timeout", 0.0, (last.ts - entry_ts).total_seconds() / 60.0


def cost_points_at_entry(c: Candle, base_cost_points: float, multiplier: float) -> float:
    raw = c.spread if c.spread is not None and c.spread >= 0 else base_cost_points
    # Use at least the configured base cost to avoid under-costing feeds with missing or unrealistically tiny spread.
    return max(raw, base_cost_points) * multiplier


def scan_config(
    candles: Sequence[Candle],
    days: Dict[str, List[Candle]],
    config: Config,
    observed_spread_p75: Optional[float],
    base_cost_points: float,
    cost_multiplier: float,
) -> Tuple[List[Trade], Dict[str, int]]:
    trades: List[Trade] = []
    skip_counts: Dict[str, int] = {}
    dates = sorted(days.keys())
    for current_day in dates:
        day_rows = days[current_day]
        if config.reference_range == "Asia":
            ref = asia_range_for_day(day_rows)
        elif config.reference_range == "PriorDay":
            ref = prior_day_range(days, current_day)
        else:
            ref = None
        if ref is None:
            skip_counts["missing_reference_range"] = skip_counts.get("missing_reference_range", 0) + 1
            continue
        ref_low, ref_high, ref_mid = ref
        rows = active_rows(day_rows, config.active_window)
        if len(rows) < 3:
            skip_counts["missing_active_window_rows"] = skip_counts.get("missing_active_window_rows", 0) + 1
            continue
        for side in ["long", "short"]:
            swept = False
            sweep_extreme: Optional[float] = None
            for idx, c in enumerate(rows):
                atr = c.atr14 or (ref_high - ref_low)
                if atr <= 0:
                    continue
                threshold = signal_threshold(atr, config.sweep_atr_mult)
                if side == "long":
                    if c.low <= ref_low - threshold:
                        swept = True
                        sweep_extreme = c.low if sweep_extreme is None else min(sweep_extreme, c.low)
                    if not swept:
                        continue
                    inside = ref_low < c.close < ref_high
                    confirm = c.close >= ref_low + (0.10 * atr if config.confirmation.endswith("0.10_ATR") else 0.0)
                    if not (inside and confirm):
                        continue
                    entry = c.close
                    buffer = stop_buffer(atr, observed_spread_p75, base_cost_points)
                    stop = float(sweep_extreme or c.low) - buffer
                else:
                    if c.high >= ref_high + threshold:
                        swept = True
                        sweep_extreme = c.high if sweep_extreme is None else max(sweep_extreme, c.high)
                    if not swept:
                        continue
                    inside = ref_low < c.close < ref_high
                    confirm = c.close <= ref_high - (0.10 * atr if config.confirmation.endswith("0.10_ATR") else 0.0)
                    if not (inside and confirm):
                        continue
                    entry = c.close
                    buffer = stop_buffer(atr, observed_spread_p75, base_cost_points)
                    stop = float(sweep_extreme or c.high) + buffer
                target = target_price(side, config.target_mode, entry, stop, ref_low, ref_high, ref_mid)
                if target is None:
                    skip_counts["invalid_target_stop_geometry"] = skip_counts.get("invalid_target_stop_geometry", 0) + 1
                    break
                future = rows[idx:]
                if len(future) < 2:
                    skip_counts["no_future_rows_after_entry"] = skip_counts.get("no_future_rows_after_entry", 0) + 1
                    break
                exit_price, exit_ts, reason, _unused, hold_min = resolve_trade(future, side, entry, stop, target, config.max_hold_minutes)
                cost = cost_points_at_entry(c, base_cost_points, cost_multiplier)
                if side == "long":
                    gross_points = exit_price - entry
                    benchmark_exit = future[-1].close
                    benchmark_gross = benchmark_exit - entry
                else:
                    gross_points = entry - exit_price
                    benchmark_exit = future[-1].close
                    benchmark_gross = entry - benchmark_exit
                net_points = gross_points - cost
                benchmark_net_points = benchmark_gross - cost
                net_bps = (net_points / entry) * 10000.0
                benchmark_net_bps = (benchmark_net_points / entry) * 10000.0
                trades.append(
                    Trade(
                        candidate_id=config.candidate_id,
                        side=side,
                        reference_range=config.reference_range,
                        active_window=config.active_window,
                        entry_ts=c.ts.isoformat(),
                        exit_ts=exit_ts.isoformat(),
                        entry=round(entry, 5),
                        exit=round(exit_price, 5),
                        ref_low=round(ref_low, 5),
                        ref_high=round(ref_high, 5),
                        ref_mid=round(ref_mid, 5),
                        sweep_extreme=round(float(sweep_extreme), 5),
                        stop=round(stop, 5),
                        target=round(target, 5),
                        gross_points=round(gross_points, 5),
                        net_points=round(net_points, 5),
                        net_bps=round(net_bps, 6),
                        benchmark_net_bps=round(benchmark_net_bps, 6),
                        hold_minutes=round(hold_min, 2),
                        exit_reason=reason,
                        cost_points=round(cost, 5),
                        atr14=round(atr, 5),
                    )
                )
                # Predefined cap: one trade per side per reference range per day per candidate.
                break
    return trades, skip_counts


def mean(values: Sequence[float]) -> Optional[float]:
    return statistics.mean(values) if values else None


def median(values: Sequence[float]) -> Optional[float]:
    return statistics.median(values) if values else None


def bootstrap_p10(values: Sequence[float], iterations: int = 500, seed: int = 4702) -> Optional[float]:
    if not values:
        return None
    if len(values) < 5:
        return min(values)
    rnd = random.Random(seed)
    means = []
    n = len(values)
    for _ in range(iterations):
        sample = [values[rnd.randrange(n)] for _ in range(n)]
        means.append(statistics.mean(sample))
    means.sort()
    idx = int(math.floor(0.10 * (len(means) - 1)))
    return means[idx]


def chronological_split(values: List[Trade], train_frac: float = 0.70) -> Tuple[List[Trade], List[Trade]]:
    ordered = sorted(values, key=lambda t: t.entry_ts)
    if len(ordered) < 2:
        return ordered, []
    split = max(1, min(len(ordered) - 1, int(len(ordered) * train_frac)))
    return ordered[:split], ordered[split:]


def group_mean(trades: Sequence[Trade], key_fn) -> Dict[str, float]:
    groups: Dict[str, List[float]] = {}
    for t in trades:
        groups.setdefault(key_fn(t), []).append(t.net_bps)
    return {k: statistics.mean(v) for k, v in groups.items() if v}


def parse_iso_dt(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def month_span(trades: Sequence[Trade]) -> float:
    if not trades:
        return 0.0
    dts = [parse_iso_dt(t.entry_ts) for t in trades]
    days = max(1, (max(dts) - min(dts)).days + 1)
    return max(days / 30.4375, 1.0)


def concentration_by_year(trades: Sequence[Trade]) -> Optional[float]:
    if not trades:
        return None
    counts: Dict[str, int] = {}
    for t in trades:
        y = str(parse_iso_dt(t.entry_ts).year)
        counts[y] = counts.get(y, 0) + 1
    return max(counts.values()) / len(trades)


def classify_candidate(
    metrics: Dict[str, Any],
    min_trades: int,
    soft_min_trades: int,
) -> Tuple[str, List[str]]:
    buckets: List[str] = []
    trade_count = metrics.get("trade_count", 0) or 0
    mean_net = metrics.get("mean_net_bps")
    oos = metrics.get("oos_mean_net_bps")
    worst_q = metrics.get("worst_quarter_net_bps")
    boot = metrics.get("bootstrap_p10_net_bps")
    residual = metrics.get("benchmark_residual_bps")
    cost2x = metrics.get("cost_2x_mean_net_bps")
    year_conc = metrics.get("max_year_trade_concentration")

    if trade_count == 0:
        buckets.append("no_trades")
    if trade_count < min_trades:
        buckets.append("insufficient_trades")
    if mean_net is None or mean_net <= 0:
        buckets.append("no_positive_net_edge")
    if oos is None or oos <= 0:
        buckets.append("oos_negative")
    if worst_q is None or worst_q <= 0:
        buckets.append("quarter_stability_negative")
    if boot is None or boot <= 0:
        buckets.append("bootstrap_floor_negative")
    if residual is None or residual <= 0:
        buckets.append("benchmark_residual_too_small")
    if cost2x is None or cost2x <= 0:
        buckets.append("cost_2x_negative")
    if year_conc is not None and trade_count >= min_trades and year_conc > 0.55:
        buckets.append("year_concentrated_gt_55pct")

    strict_ok = (
        trade_count >= min_trades
        and mean_net is not None and mean_net > 0
        and oos is not None and oos > 0
        and worst_q is not None and worst_q > 0
        and boot is not None and boot > 0
        and residual is not None and residual > 0
        and cost2x is not None and cost2x > 0
        and (year_conc is None or year_conc <= 0.55)
    )
    soft_ok = (
        not strict_ok
        and trade_count >= soft_min_trades
        and mean_net is not None and mean_net > 0
        and oos is not None and oos >= 0
        and boot is not None and boot > -1.0
        and residual is not None and residual > 0
    )
    if strict_ok:
        return "STRICT_SURVIVOR_RESEARCH_ONLY_NO_PROMOTION", []
    if soft_ok:
        return "SOFT_SURVIVOR_RESEARCH_ONLY_NO_PROMOTION", buckets
    return "FAIL_RESEARCH_ONLY_NO_PROMOTION", buckets


def summarize_candidate(
    config: Config,
    trades_1x: List[Trade],
    trades_2x: List[Trade],
    trades_3x: List[Trade],
    min_trades: int,
    soft_min_trades: int,
) -> Dict[str, Any]:
    nets = [t.net_bps for t in trades_1x]
    bench = [t.benchmark_net_bps for t in trades_1x]
    train, oos = chronological_split(trades_1x)
    q_means = group_mean(trades_1x, lambda t: quarter_key(parse_iso_dt(t.entry_ts)))
    sessions = group_mean(trades_1x, lambda t: t.active_window)
    years = concentration_by_year(trades_1x)
    metrics: Dict[str, Any] = {
        **asdict(config),
        "trade_count": len(trades_1x),
        "trades_per_month": round(len(trades_1x) / month_span(trades_1x), 4) if trades_1x else 0.0,
        "mean_net_bps": round(mean(nets), 6) if nets else None,
        "median_net_bps": round(median(nets), 6) if nets else None,
        "win_rate": round(sum(1 for x in nets if x > 0) / len(nets), 6) if nets else None,
        "avg_hold_minutes": round(mean([t.hold_minutes for t in trades_1x]), 4) if trades_1x else None,
        "oos_mean_net_bps": round(mean([t.net_bps for t in oos]), 6) if oos else None,
        "worst_quarter_net_bps": round(min(q_means.values()), 6) if q_means else None,
        "bootstrap_p10_net_bps": round(bootstrap_p10(nets), 6) if nets else None,
        "benchmark_mean_net_bps": round(mean(bench), 6) if bench else None,
        "benchmark_residual_bps": round((mean(nets) or 0.0) - (mean(bench) or 0.0), 6) if nets and bench else None,
        "cost_1x_mean_net_bps": round(mean([t.net_bps for t in trades_1x]), 6) if trades_1x else None,
        "cost_2x_mean_net_bps": round(mean([t.net_bps for t in trades_2x]), 6) if trades_2x else None,
        "cost_3x_mean_net_bps": round(mean([t.net_bps for t in trades_3x]), 6) if trades_3x else None,
        "session_breakdown_mean_net_bps": {k: round(v, 6) for k, v in sessions.items()},
        "max_year_trade_concentration": round(years, 6) if years is not None else None,
    }
    classification, buckets = classify_candidate(metrics, min_trades, soft_min_trades)
    metrics["classification"] = classification
    metrics["failure_buckets"] = ";".join(buckets) if buckets else ""
    return metrics


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def write_trades_csv(path: Path, trades: Sequence[Trade]) -> None:
    write_csv(path, [asdict(t) for t in trades])


def failure_bucket_counts(candidate_rows: Sequence[Dict[str, Any]]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for row in candidate_rows:
        raw = row.get("failure_buckets") or ""
        for b in str(raw).split(";"):
            b = b.strip()
            if b:
                counts[b] = counts.get(b, 0) + 1
    return dict(sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])))


def markdown_report(summary: Dict[str, Any], top_rows: Sequence[Dict[str, Any]]) -> str:
    lines: List[str] = []
    lines.append("# XAUUSD Stage47B Liquidity-Sweep Reversal Scan Report")
    lines.append("")
    lines.append(f"Generated UTC: {summary['generated_utc']}")
    lines.append("")
    lines.append("## Stage status")
    lines.append("")
    lines.append("```text")
    for key in ["stage", "status", "promotion", "EA", "paper_live", "live", "next_allowed_step"]:
        lines.append(f"{key} = {summary.get(key)}")
    lines.append("```")
    lines.append("")
    lines.append("## Design boundary")
    lines.append("")
    lines.append("This is a predefined rule-based scan for failed breakout / liquidity sweep re-entry reversal. It is not a rescue of Stage41/42/43, not a continuation of Stage46 external context, not ML, and not an execution/paper-live package.")
    lines.append("")
    lines.append("## Scan recap")
    lines.append("")
    lines.append("```text")
    for key in [
        "source_type", "source_path", "selected_table", "rows_loaded", "candidate_count",
        "strict_survivor_count", "soft_survivor_count", "fail_count", "trade_count_total",
    ]:
        if key in summary:
            lines.append(f"{key} = {summary.get(key)}")
    lines.append("```")
    lines.append("")
    lines.append("## Failure bucket counts")
    lines.append("")
    lines.append("```json")
    lines.append(json.dumps(summary.get("failure_bucket_counts", {}), indent=2, ensure_ascii=False))
    lines.append("```")
    lines.append("")
    lines.append("## Top candidates by mean net bps")
    lines.append("")
    if not top_rows:
        lines.append("No candidates were evaluated.")
    else:
        lines.append("| candidate_id | class | trades | mean_net_bps | oos_mean_net_bps | worst_q | boot_p10 | cost2x | residual |")
        lines.append("| :-- | :-- | --: | --: | --: | --: | --: | --: | --: |")
        for r in top_rows[:15]:
            lines.append(
                f"| {r.get('candidate_id')} | {r.get('classification')} | {r.get('trade_count')} | "
                f"{r.get('mean_net_bps')} | {r.get('oos_mean_net_bps')} | {r.get('worst_quarter_net_bps')} | "
                f"{r.get('bootstrap_p10_net_bps')} | {r.get('cost_2x_mean_net_bps')} | {r.get('benchmark_residual_bps')} |"
            )
    lines.append("")
    lines.append("## Interpretation rule")
    lines.append("")
    lines.append("A strict or soft survivor here is still research-only. It does not authorize EA, paper-live, or live trading. If strict and soft counts are both zero, this thesis must be killed or archived rather than rescued by post-hoc bad-bucket filtering.")
    lines.append("")
    return "\n".join(lines)


def write_no_data_outputs(out: Path, load_meta: Dict[str, Any], args: argparse.Namespace) -> None:
    out.mkdir(parents=True, exist_ok=True)
    summary = {
        "generated_utc": utc_now_iso(),
        "stage": STAGE,
        "status": STATUS_NO_DATA,
        "promotion": "NO_GO",
        "EA": "NO_GO",
        "paper_live": "NO_GO",
        "live": "NO_GO",
        "next_allowed_step": "PROVIDE_VALID_CANDLE_DATA_OR_PAUSE",
        "rows_loaded": 0,
        "candidate_count": 0,
        "strict_survivor_count": 0,
        "soft_survivor_count": 0,
        "fail_count": 0,
        "trade_count_total": 0,
        "load_meta": load_meta,
        "args": vars(args),
        "message": "No usable candle data was found. Loader stopped without promotion and without crashing.",
    }
    (out / "stage47b_liquidity_sweep_reversal_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    write_csv(out / "stage47b_liquidity_sweep_reversal_candidates.csv", [])
    write_csv(out / "stage47b_liquidity_sweep_reversal_trades.csv", [])
    (out / "stage47b_liquidity_sweep_reversal_report.md").write_text(markdown_report(summary, []), encoding="utf-8")


def run_scan(candles: List[Candle], load_meta: Dict[str, Any], args: argparse.Namespace) -> Dict[str, Any]:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    candles.sort(key=lambda c: c.ts)
    add_atr14(candles)
    timeframe = args.timeframe or estimate_timeframe(candles)
    spreads = [c.spread for c in candles if c.spread is not None and c.spread >= 0]
    spread_p75 = p75([float(s) for s in spreads])
    days = build_day_index(candles)
    configs = generate_configs(args.max_hold_minutes)

    candidate_rows: List[Dict[str, Any]] = []
    all_trades_1x: List[Trade] = []
    skip_counts_total: Dict[str, int] = {}

    for cfg in configs:
        trades1, skips = scan_config(candles, days, cfg, spread_p75, args.base_cost_points, 1.0)
        trades2, _ = scan_config(candles, days, cfg, spread_p75, args.base_cost_points, 2.0)
        trades3, _ = scan_config(candles, days, cfg, spread_p75, args.base_cost_points, 3.0)
        row = summarize_candidate(cfg, trades1, trades2, trades3, args.min_trades, args.soft_min_trades)
        row["skip_counts"] = json.dumps(skips, ensure_ascii=False, sort_keys=True)
        candidate_rows.append(row)
        all_trades_1x.extend(trades1)
        for k, v in skips.items():
            skip_counts_total[k] = skip_counts_total.get(k, 0) + v

    candidate_rows.sort(
        key=lambda r: (
            r.get("classification", ""),
            r.get("mean_net_bps") if r.get("mean_net_bps") is not None else -10**9,
        ),
        reverse=True,
    )
    strict_count = sum(1 for r in candidate_rows if str(r.get("classification", "")).startswith("STRICT"))
    soft_count = sum(1 for r in candidate_rows if str(r.get("classification", "")).startswith("SOFT"))
    fail_count = len(candidate_rows) - strict_count - soft_count
    fb_counts = failure_bucket_counts(candidate_rows)

    if strict_count == 0 and soft_count == 0:
        next_step = "KILL_OR_ARCHIVE_STAGE47B_NO_RESCUE_IF_CONFIRMED"
    else:
        next_step = "STAGE47C_STRICT_AUDIT_OF_SURVIVORS_ONLY"

    summary: Dict[str, Any] = {
        "generated_utc": utc_now_iso(),
        "stage": STAGE,
        "status": STATUS_COMPLETE,
        "promotion": "NO_GO",
        "EA": "NO_GO",
        "paper_live": "NO_GO",
        "live": "NO_GO",
        "next_allowed_step": next_step,
        "selected_thesis_id": "STRUCT47_A_LIQUIDITY_SWEEP_REVERSAL",
        "source_type": load_meta.get("source_type"),
        "source_path": load_meta.get("source_path"),
        "selected_table": load_meta.get("selected_table"),
        "timeframe_estimate": timeframe,
        "rows_loaded": len(candles),
        "first_ts": candles[0].ts.isoformat() if candles else None,
        "last_ts": candles[-1].ts.isoformat() if candles else None,
        "days_loaded": len(days),
        "observed_spread_p75": spread_p75,
        "base_cost_points": args.base_cost_points,
        "candidate_count": len(candidate_rows),
        "strict_survivor_count": strict_count,
        "soft_survivor_count": soft_count,
        "fail_count": fail_count,
        "trade_count_total": len(all_trades_1x),
        "failure_bucket_counts": fb_counts,
        "skip_counts_total": skip_counts_total,
        "load_meta": load_meta,
        "hard_prohibitions": [
            "NO_RESCUE_STAGE41_42_43",
            "NO_STAGE46_EXTERNAL_CONTEXT_CONTINUATION",
            "NO_POST_HOC_BAD_BUCKET_TUNING",
            "NO_ML",
            "NO_EA_PAPER_LIVE_LIVE",
        ],
    }

    (out / "stage47b_liquidity_sweep_reversal_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    write_csv(out / "stage47b_liquidity_sweep_reversal_candidates.csv", candidate_rows)
    write_trades_csv(out / "stage47b_liquidity_sweep_reversal_trades.csv", all_trades_1x)
    top = sorted(candidate_rows, key=lambda r: r.get("mean_net_bps") if r.get("mean_net_bps") is not None else -10**9, reverse=True)
    (out / "stage47b_liquidity_sweep_reversal_report.md").write_text(markdown_report(summary, top), encoding="utf-8")
    return summary


def make_smoke_csv(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    start = datetime(2024, 1, 1, 0, 0, tzinfo=timezone.utc)
    rows: List[Dict[str, Any]] = []
    price = 2050.0
    for i in range(12 * 24 * 90):  # 90 days of M5 candles
        ts = start + timedelta(minutes=5 * i)
        day_i = i // (12 * 24)
        minute = in_minutes(ts)
        drift = math.sin(i / 35.0) * 0.35 + math.sin(i / 113.0) * 0.55
        op = price
        close = op + drift * 0.25
        high = max(op, close) + 0.55
        low = min(op, close) - 0.55
        # Inject recurring Asia-low sweep and reversal during London.
        if minute == 7 * 60 + 20 and day_i % 3 == 0:
            low -= 3.0
            close = op + 0.8
            high = max(high, close + 0.2)
        # Inject recurring Asia-high sweep and reversal during NY.
        if minute == 13 * 60 + 25 and day_i % 4 == 0:
            high += 3.2
            close = op - 0.9
            low = min(low, close - 0.2)
        rows.append(
            {
                "timestamp": ts.isoformat(),
                "open": round(op, 5),
                "high": round(high, 5),
                "low": round(low, 5),
                "close": round(close, 5),
                "spread": 0.35,
                "symbol": "XAUUSD",
                "timeframe": "M5",
            }
        )
        price = close + math.sin(i / 17.0) * 0.10
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def latest_existing(paths: Sequence[Path]) -> Optional[Path]:
    existing = [p for p in paths if p.exists() and p.is_file() and p.stat().st_size > 0]
    if not existing:
        return None
    return sorted(existing, key=lambda p: (p.stat().st_mtime, str(p)), reverse=True)[0]


def tf_filename_tokens(preferred_timeframe: Optional[str]) -> List[str]:
    """Return filename tokens that are safe for glob discovery.

    LoaderFix3 deliberately avoids short tokens such as ``5m`` because they
    match filenames like ``15min`` by substring. Short aliases are handled by
    exact-token regex scoring in filename_timeframe_score().
    """
    tf = normalize_tf(preferred_timeframe) or "M5"
    if tf == "M5":
        return ["5min", "M5"]
    if tf == "M15":
        return ["15min", "M15"]
    if tf == "M1":
        return ["1min", "M1"]
    if tf == "M30":
        return ["30min", "M30"]
    if tf == "H1":
        return ["1h", "H1", "60min"]
    return [tf, tf.lower()]


def filename_timeframe_score(path: Path, preferred_timeframe: Optional[str]) -> int:
    """Strictly score filename timeframe matches without 5m/15min bleed-through."""
    tf = normalize_tf(preferred_timeframe) or "M5"
    name = path.name.lower()
    stem = path.stem.lower()
    # Split on common file-name delimiters. Keep compact names checked below.
    parts = [x for x in re.split(r"[^a-z0-9]+", stem) if x]
    part_set = set(parts)

    exact_aliases = {
        "M1": {"m1", "1min", "1minute"},
        "M5": {"m5", "5min", "5minute"},
        "M15": {"m15", "15min", "15minute"},
        "M30": {"m30", "30min", "30minute"},
        "H1": {"h1", "1h", "1hr", "60min"},
    }.get(tf, {tf.lower()})

    if part_set.intersection(exact_aliases):
        return 100

    # Fallback for compact names. Negative lookaround prevents 5m from matching 15min.
    regexes = {
        "M1": [r"(?<!\d)1min(?![a-z0-9])", r"(?<![a-z0-9])m1(?!\d)", r"(?<!\d)1m(?![a-z0-9])"],
        "M5": [r"(?<!\d)5min(?![a-z0-9])", r"(?<![a-z0-9])m5(?!\d)", r"(?<!\d)5m(?![a-z0-9])"],
        "M15": [r"(?<!\d)15min(?![a-z0-9])", r"(?<![a-z0-9])m15(?!\d)", r"(?<!\d)15m(?![a-z0-9])"],
        "M30": [r"(?<!\d)30min(?![a-z0-9])", r"(?<![a-z0-9])m30(?!\d)", r"(?<!\d)30m(?![a-z0-9])"],
        "H1": [r"(?<![a-z0-9])h1(?!\d)", r"(?<!\d)1h(?![a-z0-9])", r"(?<!\d)60min(?![a-z0-9])"],
    }.get(tf, [re.escape(tf.lower())])
    if any(re.search(rx, name) for rx in regexes):
        return 80
    return 0


def timeframe_sql_aliases(preferred_timeframe: Optional[str]) -> List[str]:
    tf = normalize_tf(preferred_timeframe) or "M5"
    aliases = {
        "M1": ["M1", "1M", "1MIN", "1", "01"],
        "M5": ["M5", "5M", "5MIN", "5", "05"],
        "M15": ["M15", "15M", "15MIN", "15"],
        "M30": ["M30", "30M", "30MIN", "30"],
        "H1": ["H1", "1H", "1HR", "1HOUR", "60M", "60MIN", "60"],
    }
    return aliases.get(tf, [tf])


def discover_csv_source(root: Path, preferred_timeframe: Optional[str]) -> Tuple[Optional[Path], Dict[str, Any]]:
    meta: Dict[str, Any] = {
        "checked_csv_patterns": [],
        "csv_candidates": [],
        "loaderfix": "LoaderFix3_EXACT_TIMEFRAME_FILENAME_MATCH_NO_PYCACHE",
    }
    norm_dir = root / "data" / "normalized"
    if not norm_dir.exists():
        meta["error"] = "NORMALIZED_DIR_NOT_FOUND"
        return None, meta

    candidates: List[Path] = []
    for token in tf_filename_tokens(preferred_timeframe):
        patterns = [
            f"normalized_*XAU*{token}*.csv",
            f"*XAU*{token}*.csv",
            f"*{token}*.csv",
        ]
        for pat in patterns:
            meta["checked_csv_patterns"].append(str(norm_dir / pat))
            candidates.extend(norm_dir.glob(pat))

    # Also inspect all top-level normalized CSV files, but only use exact timeframe scoring.
    meta["checked_csv_patterns"].append(str(norm_dir / "*.csv"))
    candidates.extend(norm_dir.glob("*.csv"))

    # Avoid duplicates and prefer normalized XAU files. Do not recurse into archive/.venv/.git.
    unique = sorted(set(candidates), key=lambda p: str(p))
    scored: List[Tuple[int, float, Path]] = []
    for path in unique:
        if not path.is_file() or path.stat().st_size <= 0:
            continue
        name = path.name.lower()
        tf_score = filename_timeframe_score(path, preferred_timeframe)
        score = 0
        if "normalized" in name:
            score += 10
        if "xau" in name:
            score += 10
        score += tf_score
        # A CSV with the wrong timeframe can still appear in candidate logs, but it cannot win.
        if tf_score <= 0 and preferred_timeframe:
            score -= 1000
        scored.append((score, path.stat().st_mtime, path))

    ranked = sorted(scored, reverse=True)
    meta["csv_candidates"] = [str(x[2]) for x in ranked[:20]]
    meta["csv_candidate_scores"] = [
        {"score": int(x[0]), "mtime": float(x[1]), "path": str(x[2])} for x in ranked[:20]
    ]
    if not ranked or ranked[0][0] < 0:
        meta["error"] = "NO_EXACT_TIMEFRAME_CSV_CANDIDATE_FOUND"
        return None, meta
    choice = ranked[0][2]
    meta["selected_csv"] = str(choice)
    return choice, meta


def discover_db_source(root: Path) -> Tuple[Optional[Path], Dict[str, Any]]:
    sqlite_candidates = [
        root / "data/local/xauusd_local_store.sqlite",
        root / "data/store/xauusd.sqlite",
        root / "state/xauusd.db",
        root / "state/xauusd.sqlite",
        root / "data/store/xauusd_local_store.sqlite",
        root / "xauusd.sqlite",
        root / "xauusd.db",
    ]
    meta: Dict[str, Any] = {"checked_sqlite": [str(p) for p in sqlite_candidates]}
    choice = latest_existing(sqlite_candidates)
    if choice is None:
        meta["error"] = "NO_SQLITE_CANDIDATES_FOUND"
        return None, meta
    meta["selected_db"] = str(choice)
    return choice, meta


def discover_default_source(root: Path, preferred_timeframe: Optional[str], prefer_source: str = "csv") -> Tuple[Optional[str], Optional[Path], Dict[str, Any]]:
    """Find a project candle source without recursively scanning archive/.git/.venv.

    LoaderFix2 deliberately prefers the small top-level normalized CSV files by
    default. The previous DB-first auto-discovery could select a large SQLite
    store and make the scan appear to hang on macOS.
    """
    root = root.expanduser().resolve()
    meta: Dict[str, Any] = {
        "source_type": "auto",
        "root": str(root),
        "prefer_source": prefer_source,
        "note": "LoaderFix3 uses bounded top-level discovery and exact timeframe filename matching; no recursive scan of archive/.git/.venv.",
    }

    order = ["csv", "db"] if prefer_source != "db" else ["db", "csv"]
    for kind in order:
        if kind == "csv":
            csv_choice, csv_meta = discover_csv_source(root, preferred_timeframe)
            meta["csv_discovery"] = csv_meta
            if csv_choice is not None:
                meta["selected_by_autodiscovery"] = str(csv_choice)
                return "csv", csv_choice, meta
        else:
            db_choice, db_meta = discover_db_source(root)
            meta["db_discovery"] = db_meta
            if db_choice is not None:
                meta["selected_by_autodiscovery"] = str(db_choice)
                return "db", db_choice, meta

    meta["error"] = "AUTO_SOURCE_NOT_FOUND"
    return None, None, meta

def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Stage47B XAUUSD liquidity-sweep reversal research scan")
    src = p.add_mutually_exclusive_group()
    src.add_argument("--db", default=None, help="SQLite DB path containing candle data. If omitted with --csv, the script auto-discovers project defaults.")
    src.add_argument("--csv", default=None, help="CSV path containing candle data. If omitted with --db, the script auto-discovers project defaults.")
    p.add_argument("--table", default=None, help="SQLite table name; optional, auto-detected if omitted")
    p.add_argument("--symbol", default="XAUUSD", help="Symbol filter if symbol column exists")
    p.add_argument("--timeframe", default="M5", help="Timeframe filter if timeframe column exists, e.g. M5 or M15. Common source values such as 5min/5M are normalized.")
    p.add_argument("--out", default="reports/stage47b", help="Output directory")
    p.add_argument("--base-cost-points", type=float, default=0.50, help="Minimum round-trip cost in XAUUSD price points")
    p.add_argument("--max-hold-minutes", type=int, default=360, help="Strict max hold horizon in minutes")
    p.add_argument("--min-trades", type=int, default=30, help="Minimum trades for strict survivor classification")
    p.add_argument("--soft-min-trades", type=int, default=20, help="Minimum trades for soft survivor classification")
    p.add_argument("--limit", type=int, default=0, help="Optional max rows to load, 0 means all")
    p.add_argument("--db-row-cap", type=int, default=300000, help="Safety cap for SQLite rows after SQL filtering. Set 0 to disable only with --allow-large-db.")
    p.add_argument("--allow-large-db", action="store_true", help="Allow SQLite scans above --db-row-cap. Prefer normalized CSV unless you really need DB scan.")
    p.add_argument("--prefer-source", choices=["csv", "db"], default="csv", help="Auto-discovery priority when --db/--csv is omitted. Default csv avoids large DB hangs.")
    p.add_argument("--debug-source", action="store_true", help="Only print auto-discovery diagnostics and exit without scanning")
    p.add_argument("--smoke-test", action="store_true", help="Generate synthetic M5 data and run the scanner against it")
    p.add_argument("--source-root", default=".", help="Project root used for auto-discovery when --db/--csv is omitted")
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    out = Path(args.out)

    if args.base_cost_points < 0:
        parser.error("--base-cost-points must be non-negative")
    if args.max_hold_minutes <= 0:
        parser.error("--max-hold-minutes must be positive")
    if args.db_row_cap < 0:
        parser.error("--db-row-cap must be non-negative")

    if args.debug_source:
        source_kind, source_path, auto_meta = discover_default_source(Path(args.source_root), args.timeframe, args.prefer_source)
        payload = {
            "stage": STAGE,
            "debug_source": True,
            "source_kind": source_kind,
            "source_path": str(source_path) if source_path is not None else None,
            "auto_meta": auto_meta,
            "cwd": str(Path.cwd()),
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0

    if args.smoke_test:
        smoke_csv = out / "_smoke_stage47b_m5.csv"
        make_smoke_csv(smoke_csv)
        candles, meta = load_csv(smoke_csv, args.symbol, args.timeframe or "M5", args.limit)
    elif args.csv:
        candles, meta = load_csv(Path(args.csv), args.symbol, args.timeframe, args.limit)
    elif args.db:
        candles, meta = load_sqlite(Path(args.db), args.table, args.symbol, args.timeframe, args.limit, args.db_row_cap, args.allow_large_db)
    else:
        source_kind, source_path, auto_meta = discover_default_source(Path(args.source_root), args.timeframe, args.prefer_source)
        if source_kind == "db" and source_path is not None:
            candles, meta = load_sqlite(source_path, args.table, args.symbol, args.timeframe, args.limit, args.db_row_cap, args.allow_large_db)
            meta["autodiscovery"] = auto_meta
        elif source_kind == "csv" and source_path is not None:
            candles, meta = load_csv(source_path, args.symbol, args.timeframe, args.limit)
            meta["autodiscovery"] = auto_meta
        else:
            candles, meta = [], auto_meta

    if len(candles) < 200:
        meta["stop_reason"] = "INSUFFICIENT_CANDLES_MIN_200"
        write_no_data_outputs(out, meta, args)
        print(json.dumps({"stage": STAGE, "status": STATUS_NO_DATA, "rows_loaded": len(candles), "out": str(out)}, ensure_ascii=False))
        return 0

    summary = run_scan(candles, meta, args)
    print(json.dumps({
        "stage": summary["stage"],
        "status": summary["status"],
        "candidate_count": summary["candidate_count"],
        "strict_survivor_count": summary["strict_survivor_count"],
        "soft_survivor_count": summary["soft_survivor_count"],
        "next_allowed_step": summary["next_allowed_step"],
        "out": str(out),
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
